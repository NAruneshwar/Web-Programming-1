# Game-Distribution-Service
A platform created using NodeJS express and Mongodb to search and download games. Users can also review and comment on each game.
Run project using npm start
load the DB dump provided.
admin username: phill
password: Password@2020